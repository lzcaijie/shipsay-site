<?php
/**
 * ShipSay CMS - site sync endpoint (v5)
 * Path: /www/api/site_sync.php
 */
header('Content-Type: application/json; charset=utf-8');

function ss_resp($arr){
  echo json_encode($arr, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  exit;
}

function ss_log_line($path, $line){
  if (!$path) return;
  @file_put_contents($path, '['.date('Y-m-d H:i:s').'] '.$line."\n", FILE_APPEND);
}

function ss_rrmdir($dir){
  if (!is_dir($dir)) return;
  $it = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::CHILD_FIRST
  );
  foreach ($it as $f){
    $p = $f->getPathname();
    if ($f->isDir()) @rmdir($p);
    else @unlink($p);
  }
  @rmdir($dir);
}

function ss_clean_nonce_files($bakdir, $ttl){
  $ttl = (int)$ttl;
  if ($ttl < 60) $ttl = 600;
  $now = time();
  $files = glob($bakdir . '/nonce_*');
  if (!$files) return;
  foreach ($files as $f){
    if (!is_file($f)) continue;
    $age = $now - @filemtime($f);
    if ($age > $ttl * 5) @unlink($f);
  }
}

function ss_clean_old_bundles($bakdir, $keep = 30){
  $keep = (int)$keep;
  if ($keep < 3) $keep = 3;
  $dirs = glob($bakdir . '/bundle_*');
  if (!$dirs) return;
  $dirs = array_values(array_filter($dirs, 'is_dir'));
  if (count($dirs) <= $keep) return;
  rsort($dirs);
  $del = array_slice($dirs, $keep);
  foreach ($del as $d) ss_rrmdir($d);
}


function ss_php_sq($s){
  $s = (string)$s;
  $s = str_replace('\\', '/', $s); // 与后台一致：root_dir 统一 /
  $s = str_replace(['\\', "'"], ['\\\\', "\\'"], $s);
  return $s;
}

function ss_mask_snapshot($snap){
  if (!is_array($snap)) return $snap;
  $out = $snap;
  if (!empty($out['config']) && is_array($out['config'])) {
    if (isset($out['config']['dbpass'])) $out['config']['dbpass'] = '***';
    if (isset($out['config']['db_pass'])) $out['config']['db_pass'] = '***';
  }
  return $out;
}

function ss_get_client_ip($trust_proxy){
  $ip = $_SERVER['REMOTE_ADDR'] ?? '';
  if ($trust_proxy) {
    $xff = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
    if ($xff) {
      $parts = array_map('trim', explode(',', $xff));
      if (!empty($parts[0])) $ip = $parts[0];
    }
  }
  return (string)$ip;
}

function ss_is_empty($v){
  return $v === '' || $v === null;
}

function ss_tristate_keep($v){
  return is_numeric($v) && (int)$v === -1;
}

function ss_extract_sortarr_src($config_file){
  if (!is_file($config_file)) return '';
  $txt = @file_get_contents($config_file);
  if ($txt === false) return '';
  if (preg_match('~//\s*分类设置\s*\R(.*?)\R\s*//\s*redis缓存设置~su', $txt, $m)) {
    return trim($m[1]);
  }
  return '';
}

function ss_load_override($override_file){
  $site_name = null; $theme_dir = null; $kw_pack_id = null; $enable_protect = null;
  if (is_file($override_file)) {
    include $override_file;
  }
  return [
    'site_name' => $site_name,
    'theme_dir' => $theme_dir,
    'kw_pack_id' => $kw_pack_id,
    'enable_protect' => $enable_protect,
  ];
}

function ss_load_config_ini($root){
  if (!defined('__ROOT_DIR__')) define('__ROOT_DIR__', $root);
  $file = $root . '/shipsay/configs/config.ini.php';

  // defaults
  $dbarr = ['host'=>'','port'=>'3306','name'=>'','user'=>'','pass'=>'','pconnect'=>0];
  $authcode = '';
  $sys_ver = '';
  $root_dir = '';
  $txt_url = '';
  $txt_get_mode = 1;
  $remote_img_url = '';
  $local_img = 0;
  $is_attachment = 0;
  $att_url = '';
  $site_url = '';
  $use_js = 1;
  $use_gzip = 1;
  $enable_down = 0;
  $is_ft = 0;

  $theme_dir = '';
  $is_3in1 = 0;
  $commend_ids = '';
  $category_per_page = 20;
  $readpage_split_mode = 0;
  $readpage_split_lines = 800;
  $vote_perday = 3;
  $count_visit = 0;

  $fake_info_url = '';
  $fake_chapter_url = '';
  $use_orderid = '0';
  $fake_sort_url = '';
  $fake_top = '';
  $fake_recentread = '';
  $fake_indexlist = '';
  $per_indexlist = 0;

  $sortarr = [];

  $use_redis = 0;
  $redisarr = ['host'=>'','port'=>'6379','db'=>'0','pass'=>''];
  $home_cache_time = 1200;
  $info_cache_time = 7200;
  $category_cache_time = 3600;
  $cache_time = 1800;

  $is_multiple = 0;
  $ss_newid = '$id';
  $ss_sourceid = '$id';

  $is_langtail = 0;
  $langtail_catch_cycle = 180;
  $langtail_cache_time = 2592000;
  $fake_langtail_info = '';
  $fake_langtail_indexlist = '';

  $is_keywords = 0;
  $keywords_num = 5;

  if (is_file($file)) {
    include $file;
  }

  $sitename = defined('SITE_NAME') ? SITE_NAME : '';

  $sortarr_src = ss_extract_sortarr_src($file);
  if ($sortarr_src === '' && !empty($sortarr) && is_array($sortarr)) {
    // fallback: 由数组重建
    $lines = [];
    foreach ($sortarr as $id=>$it) {
      if (!is_array($it)) continue;
      $code = $it['code'] ?? '';
      $cap = $it['caption'] ?? '';
      $lines[] = "\$sortarr[".(int)$id."] = ['code' => '".ss_php_sq($code)."', 'caption' => '".ss_php_sq($cap)."'];";
    }
    $sortarr_src = implode("\n", $lines);
  }

  return [
    'sitename' => $sitename,
    'dbhost' => (string)($dbarr['host'] ?? ''),
    'dbport' => (string)($dbarr['port'] ?? '3306'),
    'dbname' => (string)($dbarr['name'] ?? ($dbarr['dbname'] ?? '')),
    'dbuser' => (string)($dbarr['user'] ?? ''),
    'dbpass' => (string)($dbarr['pass'] ?? ''),
    'db_pconnect' => (int)($dbarr['pconnect'] ?? 0),

    'authcode' => (string)$authcode,
    'sys_ver' => (string)$sys_ver,
    'root_dir' => (string)$root_dir,
    'txt_url' => (string)$txt_url,
    'txt_get_mode' => (int)$txt_get_mode,
    'remote_img_url' => (string)$remote_img_url,
    'local_img' => (int)$local_img,
    'is_attachment' => (int)$is_attachment,
    'att_url' => (string)$att_url,
    'site_url' => (string)$site_url,
    'use_js' => (int)$use_js,
    'use_gzip' => (int)$use_gzip,
    'enable_down' => (int)$enable_down,
    'is_ft' => (int)$is_ft,

    'theme_dir' => (string)$theme_dir,
    'is_3in1' => (int)$is_3in1,
    'commend_ids' => (string)$commend_ids,
    'category_per_page' => (int)$category_per_page,
    'readpage_split_mode' => (int)$readpage_split_mode,
    'readpage_split_lines' => (int)$readpage_split_lines,
    'vote_perday' => (int)$vote_perday,
    'count_visit' => (int)$count_visit,

    'fake_info_url' => (string)$fake_info_url,
    'fake_chapter_url' => (string)$fake_chapter_url,
    'use_orderid' => (string)$use_orderid,
    'fake_sort_url' => (string)$fake_sort_url,
    'fake_top' => (string)$fake_top,
    'fake_recentread' => (string)$fake_recentread,
    'fake_indexlist' => (string)$fake_indexlist,
    'per_indexlist' => (int)$per_indexlist,

    'sortarr' => (string)$sortarr_src,

    'use_redis' => (int)$use_redis,
    'redishost' => (string)($redisarr['host'] ?? ''),
    'redisport' => (string)($redisarr['port'] ?? ''),
    'redisdb' => (string)($redisarr['db'] ?? ''),
    'redispass' => (string)($redisarr['pass'] ?? ''),
    'home_cache_time' => (int)$home_cache_time,
    'info_cache_time' => (int)$info_cache_time,
    'category_cache_time' => (int)$category_cache_time,
    'cache_time' => (int)$cache_time,

    'is_multiple' => (int)$is_multiple,
    'ss_newid' => (string)$ss_newid,
    'ss_sourceid' => (string)$ss_sourceid,

    'is_langtail' => (int)$is_langtail,
    'langtail_catch_cycle' => (int)$langtail_catch_cycle,
    'langtail_cache_time' => (int)$langtail_cache_time,
    'fake_langtail_info' => (string)$fake_langtail_info,
    'fake_langtail_indexlist' => (string)$fake_langtail_indexlist,

    'is_keywords' => (int)$is_keywords,
    'keywords_num' => (int)$keywords_num,
  ];
}

function ss_load_filter($file){
  $ShipSayFilter = ['is_filter'=>0,'filter_ini'=>''];
  if (is_file($file)) include $file;
  return [
    'is_filter' => (int)($ShipSayFilter['is_filter'] ?? 0),
    'filter_ini' => (string)trim((string)($ShipSayFilter['filter_ini'] ?? ''), "\r\n"),
  ];
}

function ss_load_link($file){
  $ShipSayLink = ['is_link'=>0,'link_ini'=>''];
  if (is_file($file)) include $file;
  return [
    'is_link' => (int)($ShipSayLink['is_link'] ?? 0),
    'link_ini' => (string)trim((string)($ShipSayLink['link_ini'] ?? ''), "\r\n"),
  ];
}

function ss_load_report($file){
  $ShipSayReport = ['on'=>false,'delay'=>30];
  if (is_file($file)) include $file;
  return [
    'report_on' => !empty($ShipSayReport['on']) ? 1 : 0,
    'report_delay' => (int)($ShipSayReport['delay'] ?? 30),
  ];
}

function ss_load_search($file){
  $ShipSaySearch = ['delay'=>5,'limit'=>50,'min_words'=>2,'cache_time'=>86400,'is_record'=>0];
  if (is_file($file)) include $file;
  return [
    'delay' => (int)($ShipSaySearch['delay'] ?? 5),
    'limit' => (int)($ShipSaySearch['limit'] ?? 50),
    'min_words' => (int)($ShipSaySearch['min_words'] ?? 2),
    'cache_time' => (int)($ShipSaySearch['cache_time'] ?? 86400),
    'is_record' => (int)($ShipSaySearch['is_record'] ?? 0),
  ];
}

function ss_load_count($file){
  $count = [];
  if (is_file($file)) include $file;
  $c1 = $count[1] ?? ['enable'=>0,'html'=>''];
  $c2 = $count[2] ?? ['enable'=>0,'html'=>''];
  $c3 = $count[3] ?? ['enable'=>0,'html'=>''];
  return [
    'count1_enable' => (int)($c1['enable'] ?? 0),
    'count1_html' => (string)($c1['html'] ?? ''),
    // 内部保留（回写时需要）
    '_count2_enable' => (int)($c2['enable'] ?? 0),
    '_count2_html' => (string)($c2['html'] ?? ''),
    '_count3_enable' => (int)($c3['enable'] ?? 0),
    '_count3_html' => (string)($c3['html'] ?? ''),
  ];
}

function ss_effective_snapshot($root){
  $cfg = ss_load_config_ini($root);
  $override_file = $root . '/shipsay/configs/override_pre.php';
  $ov = ss_load_override($override_file);

  // override_pre 优先（仅覆盖明确给出的字段）
  if (!ss_is_empty($ov['site_name'])) $cfg['sitename'] = (string)$ov['site_name'];
  if (!ss_is_empty($ov['theme_dir'])) $cfg['theme_dir'] = (string)$ov['theme_dir'];

  $snap = [
    'config' => $cfg,
    'override' => [
      'site_name' => (string)($ov['site_name'] ?? ''),
      'theme_dir' => (string)($ov['theme_dir'] ?? ''),
      'kw_pack_id' => (int)($ov['kw_pack_id'] ?? 0),
      'enable_protect' => (int)($ov['enable_protect'] ?? 0),
    ],
    'filter' => ss_load_filter($root . '/shipsay/configs/filter.ini.php'),
    'link' => ss_load_link($root . '/shipsay/configs/link.ini.php'),
    'count' => ss_load_count($root . '/shipsay/configs/count.ini.php'),
    'report' => ss_load_report($root . '/shipsay/configs/report.ini.php'),
    'search' => ss_load_search($root . '/shipsay/configs/search.ini.php'),
  ];
  return $snap;
}

function ss_patch_has_db($patch){
  if (empty($patch['config']) || !is_array($patch['config'])) return false;
  $keys = ['dbhost','dbport','dbname','dbuser','dbpass','db_pconnect'];
  foreach ($keys as $k){
    if (array_key_exists($k, $patch['config'])) return true;
  }
  return false;
}

function ss_test_db($cfg){
  $h = (string)($cfg['dbhost'] ?? '');
  $port = (int)($cfg['dbport'] ?? 0);
  $dbn = (string)($cfg['dbname'] ?? '');
  $u = (string)($cfg['dbuser'] ?? '');
  $p = (string)($cfg['dbpass'] ?? '');
  if ($h==='' || $port<=0 || $dbn==='' || $u==='') {
    return [false, 'db_fields_incomplete'];
  }
  if (!function_exists('mysqli_init')) return [false, 'no_mysqli'];
  $mysqli = @mysqli_init();
  if (!$mysqli) return [false, 'mysqli_init_fail'];
  @mysqli_options($mysqli, MYSQLI_OPT_CONNECT_TIMEOUT, 3);
  $ok = @mysqli_real_connect($mysqli, $h, $u, $p, $dbn, $port);
  if (!$ok) {
    $e = @mysqli_connect_error();
    @mysqli_close($mysqli);
    return [false, 'db_connect_failed:'.$e];
  }
  @mysqli_close($mysqli);
  return [true, 'ok'];
}

function ss_merge_section(&$base, $patch, $toggles = []){
  if (!is_array($patch)) return;
  foreach ($patch as $k=>$v){
    if (!is_string($k)) continue;

    // 三态开关：-1=保持
    if (in_array($k, $toggles, true) && ss_tristate_keep($v)) {
      continue;
    }

    // 空值不下发
    if (ss_is_empty($v)) {
      continue;
    }

    $base[$k] = $v;
  }
}

function ss_render_config_ini($cfg){
  // 与 /www/caijie/savecfgs.php do=base 的拼接结构对齐
  $sortarr_src = (string)($cfg['sortarr'] ?? '');
  $sortarr_src = trim($sortarr_src);

  $ss_newid_expr = trim((string)($cfg['ss_newid'] ?? '$id'));
  $ss_sourceid_expr = trim((string)($cfg['ss_sourceid'] ?? '$id'));

  $tmp_readpage_split_mode = isset($cfg['readpage_split_mode']) ? (int)$cfg['readpage_split_mode'] : 0;

  $saveStr = "<?php if (!defined('__ROOT_DIR__')) exit;\r\n";
  $saveStr .= "error_reporting(0);\r\n";
  $saveStr .= "date_default_timezone_set('Asia/ChongQing');\r\n";
  $saveStr .= "include_once __ROOT_DIR__ . '/shipsay/version.php';\r\n";
  $saveStr .= "define('SITE_NAME', '".ss_php_sq($cfg['sitename'] ?? '')."');\r\n";
  $saveStr .= "\$dbarr = [\r\n";
  $saveStr .= "     'host' => '".ss_php_sq($cfg['dbhost'] ?? '')."'\r\n";
  $saveStr .= "    ,'port' => '".ss_php_sq($cfg['dbport'] ?? '')."'\r\n";
  $saveStr .= "    ,'name' => '".ss_php_sq($cfg['dbname'] ?? '')."'\r\n";
  $saveStr .= "    ,'user' => '".ss_php_sq($cfg['dbuser'] ?? '')."'\r\n";
  $saveStr .= "    ,'pass' => '".ss_php_sq($cfg['dbpass'] ?? '')."'\r\n";
  $saveStr .= "    ,'pconnect' => ".(int)($cfg['db_pconnect'] ?? 0)."\r\n";
  $saveStr .= "];\r\n";
  $saveStr .= "\$authcode = '".ss_php_sq($cfg['authcode'] ?? '')."';\r\n\r\n";

  $saveStr .= "\$sys_ver = '".ss_php_sq($cfg['sys_ver'] ?? '')."';\r\n";
  $saveStr .= "\$root_dir = '".ss_php_sq($cfg['root_dir'] ?? '')."';\r\n";
  $saveStr .= "\$txt_url = '".ss_php_sq($cfg['txt_url'] ?? '')."';              \r\n";
  $saveStr .= "\$txt_get_mode = ".(int)($cfg['txt_get_mode'] ?? 1).";              \r\n";
  $saveStr .= "\$remote_img_url = '".ss_php_sq($cfg['remote_img_url'] ?? '')."';\r\n";
  $saveStr .= "\$local_img = ".(int)($cfg['local_img'] ?? 0).";            \r\n";
  $saveStr .= "\$is_attachment = ".(int)($cfg['is_attachment'] ?? 0).";    \r\n";
  $saveStr .= "\$att_url = '".ss_php_sq($cfg['att_url'] ?? '')."';              \r\n";
  $saveStr .= "\$site_url = '".ss_php_sq($cfg['site_url'] ?? '')."';\r\n";
  $saveStr .= "\$use_js = ".(int)($cfg['use_js'] ?? 1).";\r\n";
  $saveStr .= "\$use_gzip = ".(int)($cfg['use_gzip'] ?? 1).";\r\n";
  $saveStr .= "\$enable_down = ".(int)($cfg['enable_down'] ?? 0).";\r\n";
  $saveStr .= "\$is_ft = ".(int)($cfg['is_ft'] ?? 0)."; \r\n\r\n";

  $saveStr .= "\$theme_dir = '".ss_php_sq($cfg['theme_dir'] ?? '')."';\r\n";
  $saveStr .= "\$is_3in1 = ".(int)($cfg['is_3in1'] ?? 0).";\r\n";
  $saveStr .= "\$commend_ids = '".ss_php_sq($cfg['commend_ids'] ?? '')."';\r\n";
  $saveStr .= "\$category_per_page = ".(int)($cfg['category_per_page'] ?? 20).";\r\n";
  $saveStr .= "\$readpage_split_mode = ".$tmp_readpage_split_mode.";\r\n";
  $saveStr .= "\$readpage_split_lines = ".(int)($cfg['readpage_split_lines'] ?? 800).";\r\n";
  $saveStr .= "\$vote_perday = ".(int)($cfg['vote_perday'] ?? 3).";\r\n";
  $saveStr .= "\$count_visit = ".(int)($cfg['count_visit'] ?? 0).";\r\n\r\n";

  $saveStr .= "\$fake_info_url = '".ss_php_sq($cfg['fake_info_url'] ?? '')."';      \r\n";
  $saveStr .= "\$fake_chapter_url = '".ss_php_sq($cfg['fake_chapter_url'] ?? '')."';\r\n";
  $saveStr .= "\$use_orderid = '".ss_php_sq($cfg['use_orderid'] ?? '0')."';\r\n";
  $saveStr .= "\$fake_sort_url = '".ss_php_sq($cfg['fake_sort_url'] ?? '')."';      \r\n";
  $saveStr .= "\$fake_top = '".ss_php_sq($cfg['fake_top'] ?? '')."';        \r\n";
  $saveStr .= "\$fake_recentread = '".ss_php_sq($cfg['fake_recentread'] ?? '')."';\r\n";
  $saveStr .= "\$fake_indexlist = '".ss_php_sq($cfg['fake_indexlist'] ?? '')."';  \r\n";
  $saveStr .= "\$per_indexlist = ".(int)($cfg['per_indexlist'] ?? 0).";\r\n\r\n";

  $saveStr .= "//分类设置\r\n" . $sortarr_src . "\r\n\r\n";

  $saveStr .= "//redis缓存设置\r\n";
  $saveStr .= "\$use_redis = ".(int)($cfg['use_redis'] ?? 0).";\r\n";
  $saveStr .= "\$redisarr = [\r\n";
  $saveStr .= "     'host' => '".ss_php_sq($cfg['redishost'] ?? '')."' \r\n";
  $saveStr .= "    ,'port' => '".ss_php_sq($cfg['redisport'] ?? '')."' \r\n";
  $saveStr .= "    ,'db' => '".ss_php_sq($cfg['redisdb'] ?? '')."'\r\n";
  $saveStr .= "    ,'pass' => '".ss_php_sq($cfg['redispass'] ?? '')."'\r\n";
  $saveStr .= "];\r\n";
  $saveStr .= "\$home_cache_time = ".(int)($cfg['home_cache_time'] ?? 1200).";        \r\n";
  $saveStr .= "\$info_cache_time = ".(int)($cfg['info_cache_time'] ?? 7200).";        \r\n";
  $saveStr .= "\$category_cache_time = ".(int)($cfg['category_cache_time'] ?? 3600).";\r\n";
  $saveStr .= "\$cache_time = ".(int)($cfg['cache_time'] ?? 1800).";                  \r\n\r\n";

  $saveStr .= "//ID混淆\r\n";
  $saveStr .= "\$is_multiple = ".(int)($cfg['is_multiple'] ?? 0).";\r\n";
  $saveStr .= "\$ss_newid = '".ss_php_sq($ss_newid_expr)."';\r\n";
  $saveStr .= "function ss_newid(\$id){\r\n";
  $saveStr .= "    return ".$ss_newid_expr.";\r\n";
  $saveStr .= "}\r\n";
  $saveStr .= "\$ss_sourceid = '".ss_php_sq($ss_sourceid_expr)."';\r\n";
  $saveStr .= "function ss_sourceid(\$id){\r\n";
  $saveStr .= "    return ".$ss_sourceid_expr.";\r\n";
  $saveStr .= "}\r\n\r\n";

  $saveStr .= "\$is_langtail = ".(int)($cfg['is_langtail'] ?? 0).";\r\n";
  $saveStr .= "\$langtail_catch_cycle = ".(int)($cfg['langtail_catch_cycle'] ?? 180).";\r\n";
  $saveStr .= "\$langtail_cache_time = ".(int)($cfg['langtail_cache_time'] ?? 2592000).";\r\n";
  $saveStr .= "\$fake_langtail_info = '".ss_php_sq($cfg['fake_langtail_info'] ?? '')."';\r\n";
  $saveStr .= "\$fake_langtail_indexlist = '".ss_php_sq($cfg['fake_langtail_indexlist'] ?? '')."';\r\n\r\n";

  $saveStr .= "\$is_keywords = ".(int)($cfg['is_keywords'] ?? 0).";\r\n";
  $saveStr .= "\$keywords_num = ".(int)($cfg['keywords_num'] ?? 5).";\r\n";

  return $saveStr;
}

function ss_render_filter_ini($v){
  $ini = (string)($v['filter_ini'] ?? '');
  $ini = str_replace("'", "\\'", $ini);
  $saveStr = "<?php\r\n\$ShipSayFilter['is_filter'] = ".(int)($v['is_filter'] ?? 0)."; \r\n\$ShipSayFilter['filter_ini'] = '\r\n".$ini."\r\n';";
  return $saveStr;
}

function ss_render_link_ini($v){
  $ini = (string)($v['link_ini'] ?? '');
  $ini = str_replace("'", "\\'", $ini);
  $saveStr = "<?php\r\n\$ShipSayLink['is_link'] = ".(int)($v['is_link'] ?? 0)."; \r\n\$ShipSayLink['link_ini'] = ' \r\n".$ini."\r\n';";
  return $saveStr;
}

function ss_render_report_ini($v){
  $on = !empty($v['report_on']) ? 'true' : 'false';
  $delay = (int)($v['report_delay'] ?? 30);
  return "<?php\r\n\$ShipSayReport['on'] = ".$on."; \r\n\$ShipSayReport['delay'] = ".$delay."; \r\n";
}

function ss_render_search_ini($v){
  return "<?php\r\n\r\n\$ShipSaySearch = [\r\n    'delay' => ".(int)($v['delay'] ?? 5)." \r\n    ,'limit' => ".(int)($v['limit'] ?? 50)."\r\n    ,'min_words' => ".(int)($v['min_words'] ?? 2)."\r\n    ,'cache_time' => ".(int)($v['cache_time'] ?? 86400)."\r\n    ,'is_record' => ".(int)($v['is_record'] ?? 0)."\r\n];\r\n";
}

function ss_render_count_ini($cur_count, $patch_count){
  // 只写 count[1]
  $c1_enable = isset($patch_count['count1_enable']) ? (int)$patch_count['count1_enable'] : (int)($cur_count['count1_enable'] ?? 0);
  $c1_html = isset($patch_count['count1_html']) ? (string)$patch_count['count1_html'] : (string)($cur_count['count1_html'] ?? '');

  $c2_enable = (int)($cur_count['_count2_enable'] ?? 0);
  $c2_html = (string)($cur_count['_count2_html'] ?? '');
  $c3_enable = (int)($cur_count['_count3_enable'] ?? 0);
  $c3_html = (string)($cur_count['_count3_html'] ?? '');

  $c1_html = str_replace("'", "\\'", $c1_html);
  $c2_html = str_replace("'", "\\'", $c2_html);
  $c3_html = str_replace("'", "\\'", $c3_html);

  $saveStr = "<?php\r\n\r\n\$count[1] = [\r\n    'enable' => ".$c1_enable.",\r\n    'html' => '".$c1_html."'\r\n];\r\n\$count[2] = [\r\n    'enable' => ".$c2_enable.",\r\n    'html' => '".$c2_html."'\r\n];\r\n\$count[3] = [\r\n    'enable' => ".$c3_enable.",\r\n    'html' => '".$c3_html."'\r\n];\r\n";
  return $saveStr;
}

function ss_render_override_pre($ov){
  $site_name = ss_php_sq($ov['site_name'] ?? '');
  $theme_dir = ss_php_sq($ov['theme_dir'] ?? '');
  $kw = (int)($ov['kw_pack_id'] ?? 0);
  $ep = (int)($ov['enable_protect'] ?? 0);

  $s = "<?php\n";
  $s .= "// generated by site_sync at ".date('Y-m-d H:i:s')."\n\n";
  $s .= "\$site_name = '".$site_name."';\n";
  $s .= "\$theme_dir = '".$theme_dir."';\n";
  $s .= "\$kw_pack_id = ".$kw.";\n";
  $s .= "\$enable_protect = ".$ep.";\n";
  return $s;
}

function ss_write_atomic($path, $content){
  $dir = dirname($path);
  if (!is_dir($dir)) @mkdir($dir, 0755, true);
  $tmp = $path . '.tmp_' . bin2hex(random_bytes(3));
  if (@file_put_contents($tmp, $content) === false) return false;
  return @rename($tmp, $path);
}

function ss_backup_files($root, $bakdir, $files){
  $id = 'bundle_' . date('Ymd_His') . '_' . substr(bin2hex(random_bytes(3)),0,6);
  $bundle = $bakdir . '/' . $id;
  @mkdir($bundle, 0755, true);

  $manifest = ['id'=>$id,'ts'=>time(),'files'=>[]];
  foreach ($files as $abs){
    if (!is_string($abs) || $abs==='') continue;
    if (!is_file($abs)) continue;
    $rel = ltrim(str_replace($root, '', $abs), '/');
    $dst = $bundle . '/' . $rel;
    $dstdir = dirname($dst);
    if (!is_dir($dstdir)) @mkdir($dstdir, 0755, true);
    if (@copy($abs, $dst)) {
      $manifest['files'][] = $rel;
    }
  }
  @file_put_contents($bundle . '/manifest.json', json_encode($manifest, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
  return $bundle;
}

function ss_find_latest_bundle($bakdir){
  $dirs = glob($bakdir . '/bundle_*');
  if (!$dirs) return '';
  $dirs = array_filter($dirs, 'is_dir');
  if (!$dirs) return '';
  rsort($dirs);
  return $dirs[0];
}

function ss_rollback_bundle($root, $bundle){
  $mfile = $bundle . '/manifest.json';
  $manifest = [];
  if (is_file($mfile)) {
    $manifest = json_decode((string)file_get_contents($mfile), true);
  }
  $files = [];
  if (is_array($manifest) && !empty($manifest['files']) && is_array($manifest['files'])) {
    $files = $manifest['files'];
  } else {
    // fallback: restore all php files in bundle
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($bundle, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f){
      if ($f->isFile()) {
        $rel = ltrim(str_replace($bundle.'/', '', $f->getPathname()), '/');
        if (substr($rel,-4)==='.php') $files[] = $rel;
      }
    }
  }

  foreach ($files as $rel){
    $src = $bundle . '/' . $rel;
    $dst = $root . '/' . $rel;
    if (!is_file($src)) continue;
    $dstdir = dirname($dst);
    if (!is_dir($dstdir)) @mkdir($dstdir, 0755, true);
    @copy($src, $dst);
  }
}

// ----------------- bootstrap / security -----------------
$root = realpath(__DIR__ . '/../..');
if (!$root) ss_resp(['ok'=>0,'error'=>'bad_root']);
if (!defined('__ROOT_DIR__')) define('__ROOT_DIR__', $root);

$sync_cfg = $root . '/shipsay/configs/site_sync.php';
if (!is_file($sync_cfg)) ss_resp(['ok'=>0,'error'=>'no_site_sync_cfg']);
require $sync_cfg;

if (empty($site_sync_enable)) ss_resp(['ok'=>0,'error'=>'disabled']);
if (empty($site_sync_secret)) ss_resp(['ok'=>0,'error'=>'empty_secret']);

$trust_proxy = !empty($site_sync_trust_proxy_ip);
$client_ip = ss_get_client_ip($trust_proxy);
$allow_ips = isset($site_sync_allow_ips) && is_array($site_sync_allow_ips) ? $site_sync_allow_ips : [];
$allow_ips = array_values(array_filter(array_map('trim', $allow_ips), function($v){
  if ($v==='') return false;
  if (strpos($v,'你的')!==false) return false;
  return true;
}));
if (!empty($allow_ips) && !in_array($client_ip, $allow_ips, true)) {
  ss_resp(['ok'=>0,'error'=>'bad_ip','ip'=>$client_ip]);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) ss_resp(['ok'=>0,'error'=>'bad_json']);

$ts = $_SERVER['HTTP_X_SS_TS'] ?? '';
$nonce = $_SERVER['HTTP_X_SS_NONCE'] ?? '';
$sign = $_SERVER['HTTP_X_SS_SIGN'] ?? '';
if ($ts==='' || $nonce==='' || $sign==='') ss_resp(['ok'=>0,'error'=>'missing_headers']);
$ts_i = (int)$ts;
$ts_window = isset($site_sync_ts_window) ? (int)$site_sync_ts_window : 600;
if ($ts_window <= 0) $ts_window = 600;
if ($ts_i<=0 || abs(time()-$ts_i) > $ts_window) ss_resp(['ok'=>0,'error'=>'bad_ts']);

$body_hash = hash('sha256', $raw);
$base = "POST\n/api/site_sync.php\n{$ts}\n{$nonce}\n{$body_hash}";
$good = hash_hmac('sha256', $base, $site_sync_secret);
if (!hash_equals($good, (string)$sign)) ss_resp(['ok'=>0,'error'=>'bad_sign']);

$bakdir = $root . '/shipsay/configs/_bak';
if (!is_dir($bakdir)) @mkdir($bakdir, 0755, true);

// nonce 防重放（文件）
$nonce_ttl = isset($site_sync_nonce_ttl) ? (int)$site_sync_nonce_ttl : 600;
if ($nonce_ttl < 60) $nonce_ttl = 600;
$nonce_file = $bakdir . '/nonce_' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', (string)$nonce);
if (is_file($nonce_file)) {
  $age = time() - filemtime($nonce_file);
  if ($age >= 0 && $age < $nonce_ttl) ss_resp(['ok'=>0,'error'=>'replay_nonce']);
}
@file_put_contents($nonce_file, (string)time());
// 清理过期 nonce 文件（避免 _bak 目录越堆越大）
ss_clean_nonce_files($bakdir, $nonce_ttl);

$log_path = isset($site_sync_log) ? (string)$site_sync_log : '';
ss_log_line($log_path, $client_ip.' '.json_encode(['op'=>($data['pull']??null)?'pull':(($data['rollback']??null)?'rollback':'apply')], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));

// ----------------- operations -----------------

// Pull
if (!empty($data['pull'])) {
  $snap = ss_effective_snapshot($root);
  ss_resp(['ok'=>1,'v'=>5,'current'=>ss_mask_snapshot($snap)]);
}

// Rollback
if (!empty($data['rollback'])) {
  $bundle = ss_find_latest_bundle($bakdir);
  if (!$bundle) ss_resp(['ok'=>0,'error'=>'no_bundle_backup']);
  ss_rollback_bundle($root, $bundle);
  $snap = ss_effective_snapshot($root);
  ss_resp(['ok'=>1,'v'=>5,'rollback'=>1,'used'=>$bundle,'current'=>ss_mask_snapshot($snap),'applied'=>ss_mask_snapshot($snap)]);
}

$check_only = !empty($data['check_only']);

// normalize patch
$patch = [];
if (!empty($data['patch']) && is_array($data['patch'])) {
  $patch = $data['patch'];
} else {
  // 兼容：扁平字段（不建议使用）
  if (!empty($data['config']) && is_array($data['config'])) $patch['config'] = $data['config'];
  if (!empty($data['filter']) && is_array($data['filter'])) $patch['filter'] = $data['filter'];
  if (!empty($data['link']) && is_array($data['link'])) $patch['link'] = $data['link'];
  if (!empty($data['count']) && is_array($data['count'])) $patch['count'] = $data['count'];
  if (!empty($data['report']) && is_array($data['report'])) $patch['report'] = $data['report'];
  if (!empty($data['search']) && is_array($data['search'])) $patch['search'] = $data['search'];
  if (!empty($data['override']) && is_array($data['override'])) $patch['override'] = $data['override'];
}

if (!$patch) {
  ss_resp(['ok'=>1,'v'=>5,'check_only'=>$check_only?1:0,'would_apply'=>[]]);
}

$cur = ss_effective_snapshot($root);
$next = $cur;

// config merge
$cfg_toggles = ['use_js','use_gzip','enable_down','is_ft','is_3in1','count_visit','local_img','is_attachment','use_redis','is_multiple','is_langtail','is_keywords'];
if (!empty($patch['config']) && is_array($patch['config'])) {
  // dbpass: *** 不修改
  if (isset($patch['config']['dbpass'])) {
    $v = (string)$patch['config']['dbpass'];
    if ($v==='' || $v==='***') unset($patch['config']['dbpass']);
  }
  ss_merge_section($next['config'], $patch['config'], $cfg_toggles);
}

// override merge (kw_pack_id / enable_protect 三态)
if (!empty($patch['override']) && is_array($patch['override'])) {
  foreach (['kw_pack_id','enable_protect'] as $k){
    if (!array_key_exists($k, $patch['override'])) continue;
    $v = $patch['override'][$k];
    if (ss_tristate_keep($v)) continue;
    if (ss_is_empty($v)) continue;
    $next['override'][$k] = (int)$v;
  }
  // 允许通过 override 直接传 site_name/theme_dir（可选）
  foreach (['site_name','theme_dir'] as $k){
    if (!array_key_exists($k, $patch['override'])) continue;
    $v = $patch['override'][$k];
    if (ss_is_empty($v)) continue;
    $next['override'][$k] = (string)$v;
  }
}

// 其它模块
if (!empty($patch['filter']) && is_array($patch['filter'])) ss_merge_section($next['filter'], $patch['filter'], ['is_filter']);
if (!empty($patch['link']) && is_array($patch['link'])) ss_merge_section($next['link'], $patch['link'], ['is_link']);
if (!empty($patch['report']) && is_array($patch['report'])) ss_merge_section($next['report'], $patch['report'], ['report_on']);
if (!empty($patch['search']) && is_array($patch['search'])) ss_merge_section($next['search'], $patch['search'], ['is_record']);
if (!empty($patch['count']) && is_array($patch['count'])) ss_merge_section($next['count'], $patch['count'], ['count1_enable']);

// 同步：config.sitename/theme_dir -> override 保持一致
$next['override']['site_name'] = (string)($next['config']['sitename'] ?? '');
$next['override']['theme_dir'] = (string)($next['config']['theme_dir'] ?? '');

// check DB if needed
if (ss_patch_has_db($patch)) {
  [$ok,$detail] = ss_test_db($next['config']);
  if (!$ok) ss_resp(['ok'=>0,'error'=>'db_check_failed','detail'=>$detail]);
}

if ($check_only) {
  ss_resp(['ok'=>1,'v'=>5,'check_only'=>1,'would_apply'=>ss_mask_snapshot($next),'current'=>ss_mask_snapshot($cur)]);
}

// determine files to write
$write_files = [];
$cfg_file = $root . '/shipsay/configs/config.ini.php';
$filter_file = $root . '/shipsay/configs/filter.ini.php';
$link_file = $root . '/shipsay/configs/link.ini.php';
$count_file = $root . '/shipsay/configs/count.ini.php';
$report_file = $root . '/shipsay/configs/report.ini.php';
$search_file = $root . '/shipsay/configs/search.ini.php';
$override_file = $root . '/shipsay/configs/override_pre.php';

if (!empty($patch['config'])) $write_files[] = $cfg_file;
if (!empty($patch['filter'])) $write_files[] = $filter_file;
if (!empty($patch['link'])) $write_files[] = $link_file;
if (!empty($patch['count'])) $write_files[] = $count_file;
if (!empty($patch['report'])) $write_files[] = $report_file;
if (!empty($patch['search'])) $write_files[] = $search_file;
if (!empty($patch['override']) || !empty($patch['config'])) $write_files[] = $override_file;

$bundle = ss_backup_files($root, $bakdir, $write_files);
// 清理旧的 bundle 备份（保留最近 30 份）
ss_clean_old_bundles($bakdir, 30);

// write config.ini.php
if (in_array($cfg_file, $write_files, true)) {
  $str = ss_render_config_ini($next['config']);
  if (!ss_write_atomic($cfg_file, $str)) ss_resp(['ok'=>0,'error'=>'write_failed','file'=>'config.ini.php']);
}

if (in_array($filter_file, $write_files, true)) {
  $str = ss_render_filter_ini($next['filter']);
  if (!ss_write_atomic($filter_file, $str)) ss_resp(['ok'=>0,'error'=>'write_failed','file'=>'filter.ini.php']);
}

if (in_array($link_file, $write_files, true)) {
  $str = ss_render_link_ini($next['link']);
  if (!ss_write_atomic($link_file, $str)) ss_resp(['ok'=>0,'error'=>'write_failed','file'=>'link.ini.php']);
}

if (in_array($report_file, $write_files, true)) {
  $str = ss_render_report_ini($next['report']);
  if (!ss_write_atomic($report_file, $str)) ss_resp(['ok'=>0,'error'=>'write_failed','file'=>'report.ini.php']);
}

if (in_array($search_file, $write_files, true)) {
  $str = ss_render_search_ini($next['search']);
  if (!ss_write_atomic($search_file, $str)) ss_resp(['ok'=>0,'error'=>'write_failed','file'=>'search.ini.php']);
}

if (in_array($count_file, $write_files, true)) {
  $str = ss_render_count_ini($cur['count'], $patch['count'] ?? []);
  if (!ss_write_atomic($count_file, $str)) ss_resp(['ok'=>0,'error'=>'write_failed','file'=>'count.ini.php']);
  // 重新加载 count2/3 内部保留
  $next['count'] = ss_load_count($count_file);
}

if (in_array($override_file, $write_files, true)) {
  $str = ss_render_override_pre($next['override']);
  if (!ss_write_atomic($override_file, $str)) ss_resp(['ok'=>0,'error'=>'write_failed','file'=>'override_pre.php']);
}

$final = ss_effective_snapshot($root);
ss_resp(['ok'=>1,'v'=>5,'bundle'=>$bundle,'applied'=>ss_mask_snapshot($final),'current'=>ss_mask_snapshot($final)]);
