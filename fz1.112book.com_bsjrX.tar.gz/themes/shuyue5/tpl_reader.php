<?php if (!defined('__ROOT_DIR__')) exit; require_once __ROOT_DIR__ . '/shipsay/configs/report.ini.php';?>
<?php
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$isSearchEngine = false;
$searchEngines = [
    'Baiduspider',
    'bingbot',
    '360Spider',
    'Sogou web spider',
    'YisouSpider'
];

foreach ($searchEngines as $bot) {
    if (stripos($userAgent, $bot) !== false) {
        $isSearchEngine = true;
        break;
    }
}

$pageTitle = $articlename . ' - ' . $chaptername;
if ($max_pid > 1) {
    $pageTitle .= '（' . $now_pid . '/' . $max_pid . '）';
}
$pageTitle .= ' - ' . SITE_NAME;

$pageDescription = '《' . $articlename . '》最新章节：' . $chaptername;
if ($max_pid > 1) {
    $pageDescription .= ' 第' . $now_pid . '页/共' . $max_pid . '页';
}
$pageDescription .= '，作者：' . $author . '。';

$cateurl=$_SERVER['SERVER_PORT']==443?'https://':'http://';
$cateurl.=$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
?>
<?php require_once __ROOT_DIR__ .'/shipsay/include/neighbor.php';?>
<!DOCTYPE html>
<html lang="cmn-Hans">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?=$pageTitle?></title>
    <meta name="keywords" content="<?=$articlename?>,<?=$chaptername?>,<?=$author?>,<?=SITE_NAME?>" />
    <meta name="description" content="<?=$pageDescription?>">
    
    <meta property="og:type" content="novel">
    <meta property="og:title" content="<?=$pageTitle?>">
    <meta property="og:description" content="<?=$pageDescription?>">
    <meta property="og:novel:category" content="<?=$sortname?>小说">
    <meta property="og:novel:author" content="<?=$author?>">
    <meta property="og:novel:book_name" content="<?=$articlename?>">
    <meta property="og:novel:index_url" content="<?=$info_url?>">
    <meta property="og:novel:info_url" content="<?=$info_url?>">
    <meta property="og:novel:status" content="<?=$isfull?>">
    <meta property="og:novel:chapter_name" content="<?=$chaptername?>">
    <meta property="og:novel:chapter_url" content="<?=$cateurl?>">
    
    <link rel="canonical" href="<?=$cateurl?>">
    <meta http-equiv="Cache-Control" content="no-transform">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="renderer" content="webkit">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="MobileOptimized" content="320">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="screen-orientation" content="portrait">
    <meta name="x5-orientation" content="portrait">

    <link href="/static/<?=$theme_dir?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/<?=$theme_dir?>/css/site.css?v=<?=date('Ymd', time())?>" rel="stylesheet">
    <style>
    .loading-text {
        text-align: center;
        padding: 40px 20px;
        color: #666;
        font-size: 16px;
    }
    .error-text {
        text-align: center;
        padding: 40px 20px;
        color: #f00;
        font-size: 16px;
    }
    .spider-pagination {
        position: absolute;
        left: -9999px;
        top: -9999px;
        height: 0;
        overflow: hidden;
    }
    .spider-pagination a {
        display: inline-block;
        margin: 0 5px;
        color: #333;
        text-decoration: none;
    }

    /* 阅读页：段落间距过大修复（只作用阅读页） */
    #rtext #booktxt p{margin:0 0 16px;}
    #rtext #booktxt p:empty{display:none;margin:0;padding:0;}
    </style>
</head>
<body id="apage">
<div class="spider-pagination" aria-label="章节分页导航">
    <?php if ($max_pid > 1): ?>
        <?php if ($now_pid > 1): ?>
            <a href="<?=$prevpage_url?>" rel="prev">上一页</a>
        <?php endif; ?>
        
        <span>第<?=$now_pid?>页/共<?=$max_pid?>页</span>
        
        <?php for ($i = 1; $i <= min($max_pid, 10); $i++): ?>
            <?php if ($i == $now_pid): ?>
                <strong><?=$i?></strong>
            <?php else: ?>
                <a href="/read/<?=$articleid?>/<?=$chapterid?>/<?=$i?>.html"><?=$i?></a>
            <?php endif; ?>
        <?php endfor; ?>
        
        <?php if ($now_pid < $max_pid): ?>
            <a href="<?=$nextpage_url?>" rel="next">下一页</a>
        <?php endif; ?>
    <?php endif; ?>
</div>

<header class="header_46f navbar navbar-inverse" id="header">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><?=SITE_NAME?></a>
        </div>
        <nav class="collapse navbar-collapse" id="navbar">
            <ul class="nav navbar-nav">
                <li><a href="/">首页</a></li>
                <li><a href="/all/">书库</a></li>
                <li><a href="/rank/">排行</a></li>
                <li><a href="/full/">全本</a></li>
                <li><a href="/history.html">轨迹</a></li>
            </ul>
            <form class="navbar-form navbar-left hidden-xs" action="/search/" method="get">
                <div class="form-group">
                    <input type="text" class="form-control" name="q" value="" placeholder="搜索作品">
                </div>
                <button type="submit" class="btn btn-default">搜索</button>
            </form>
            <ul class="login_46f nav navbar-nav navbar-right" id="header-login"></ul>
        </nav>
    </div>
</header>

<div class="container body-content">
    <ol class="breadcrumb hidden-xs">
        <li><a href="/" title="<?=SITE_NAME?>"><i class="glyphicon glyphicon-home fs-14" aria-hidden="true"></i> 首页</a></li>
        <li><a href="<?=$infoarr['0']['sort_url']?>"><?=$sortname?></a></li>
        <li><a href="<?=$info_url?>"><?=$articlename?></a></li>
        <li class="active">
            <?=$chaptername?>
            <?php if ($max_pid > 1): ?>
            <span style="font-size: 14px; color: #666; margin-left: 10px;">
                （第<?=$now_pid?>页/共<?=$max_pid?>页）
            </span>
            <?php endif; ?>
        </li>
        <span class="pull-right" id="ReadSet"></span>
    </ol>

    <div class="panel panel-default" id="content">
        <div class="text-center visible-xs" id="mReadSet"></div>
        <div class="page-header text-center">
            <h1 class="readTitle">
                <?=$chaptername?>
                <?php if ($max_pid > 1): ?>
                <span style="font-size: 14px; color: #666; margin-left: 10px;">
                    （第<?=$now_pid?>页/共<?=$max_pid?>页）
                </span>
                <?php endif; ?>
            </h1>
            <p class="text-center booktag">
                <a class="blue" href="<?=$info_url?>"><i class="glyphicon glyphicon-book fs-12" aria-hidden="true"></i> <?=$articlename?></a>
                <a class="blue" href="/author/<?=$author?>" title="<?=$author?>"><i class="glyphicon glyphicon-user fs-12" aria-hidden="true"></i> <?=$author?></a>
                <a class="red" href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>','<?=$chapterid?>','<?=$chaptername?>');" rel="nofollow" id="a_addbookcase"><i class="glyphicon glyphicon-heart-empty fs-12" aria-hidden="true"></i> 加入书签</a>
            </p>
        </div>

        <div class="panel-body" id="rtext">
            <div id="booktxt">
                <article id="article" class="content">   
                    <p>天才一秒记住【<?=SITE_NAME?>】地址：<?=$site_url?></p>

                    <div id="BookText">
                        <?php if ($isSearchEngine || !Ss::use_js()): ?>
                            <?php echo $rico_content; ?>
                        <?php else: ?>
                            <div class="loading-text">正在加载章节内容...</div>
                        <?php endif; ?>
                    </div>

                    <p><?=$author?>提示您：看后求收藏（<?=$chaptername?>,<?=$articlename?>,<?=$author?>,<?=SITE_NAME?>），接着再看更方便。</p>
                </article>
            </div>
        </div>

        <div class="readPager">
            <?php if($prevpage_url != ''): ?>
                <a id="linkPrev" href="<?=$prevpage_url?>"><i class="glyphicon glyphicon-backward" aria-hidden="true"></i> 上一页</a>
            <?php else: ?>
                <?php if($pre_cid == 0): ?><a id="linkPrev" href="#" title=""><i class="glyphicon glyphicon-backward" aria-hidden="true"></i> 无上章</a><?php else: ?><a id="linkPrev" href="<?=$pre_url?>"><i class="glyphicon glyphicon-backward" aria-hidden="true"></i> 上一章</a><?php endif ?>
            <?php endif ?>

            <a id="linkIndex" href="/index/<?=$articleid?>/" disable="disabled"><i class="glyphicon glyphicon-th-list" aria-hidden="true"></i> 目 录</a>

            <?php if($nextpage_url != ''): ?>
                <a id="linkNext" href="<?=$nextpage_url?>">下一页 <i class="glyphicon glyphicon-forward" aria-hidden="true"></i></a>
            <?php else: ?>
                <?php if($next_cid == 0): ?><a rel="next" href="#" title="">无下章</a><?php else: ?><a id="linkNext" href="<?=$next_url?>">下一章 <i class="glyphicon glyphicon-forward" aria-hidden="true"></i></a><?php endif ?>
            <?php endif ?>
        </div>
    </div>

    <div class="panel panel-default" id="content2">
        <div class="panel-heading">
            <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span> <?=$sortname?>小说相关阅读<a class="pull-right" href="<?=Sort::ss_sorturl($sortid)?>">More+</a>
        </div>
        <div class="panel-body">
            <div class="row">
                <?php foreach($neighbor as $k => $v): ?><?php if($k < 3):?>
                <div class="col-xs-4 book-coverlist">
                    <div class="row">
                        <div class="col-sm-5">
                            <a href="<?=$site_url?><?=$v['info_url']?>" class="thumbnail" style="background-image:url(<?=$v['img_url']?>)"></a>
                        </div>
                        <div class="col-sm-7 pl0">
                            <div class="caption">
                                <h4 class="fs-16 text-muted"><a href="<?=$site_url?><?=$v['info_url']?>" title="<?=$v['articlename']?>"><?=$v['articlename']?></a></h4>
                                <small class="fs-14 text-muted"><?=$v['author']?></small>
                                <p class="fs-12 text-justify hidden-xs"><?=$v['intro_des']?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif ?><?php endforeach ?>
                <div class="clear"></div>
            </div>
        </div>
    </div>

    <p>《<?=$articlename?>》所有内容均来自互联网或网友上传，<?=SITE_NAME?>只为原作者<?=$author?>的小说进行宣传。欢迎各位书友支持<?=$author?>并收藏《<?=$articlename?>》最新章节</a>。</p>
    <div class="clear"></div>
</div>

<?php require_once 'tpl_footer.php'; ?>
<script src="/static/<?=$theme_dir?>/js/pagetop.js?v=<?=date('Ymd', time())?>"></script>
<script src="/static/<?=$theme_dir?>/js/tempbookcase.js?v=<?=date('Ymd', time())?>"></script>

<script>
   <?php if (Ss::use_js() && !$isSearchEngine) : ?>
      setTimeout(function() {
          $.ajax({
              type: "post",
              url: "/api/reader_js.php",
              data: {
                  articleid: '<?= $articleid ?>',
                  chapterid: '<?= $chapterid ?>',
                  pid: '<?= $now_pid ?>'
              },
              success: function(data) {
                  $('#article').html(data);
              },
              error: function() {
                  $('#article').html('<div class="error-text">加载失败，请刷新重试</div>');
              }
          });
      }, 200);
  <?php endif ?>

    lastread.set('<?=$info_url?>','<?=$uri?>','<?=$articlename?>','<?=$chaptername?>','<?=$author?>','<?=date("m-d")?>','<?=$img_url?>');
</script>
<script src="/static/<?=$theme_dir?>/js/user.js"></script>
<script src="/static/<?=$theme_dir?>/js/layer.js"></script>

