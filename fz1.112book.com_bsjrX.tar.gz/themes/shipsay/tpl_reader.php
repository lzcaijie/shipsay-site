<?php if (!defined('__ROOT_DIR__')) exit; require_once __ROOT_DIR__ . '/shipsay/configs/report.ini.php';?>
<?php
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$isSearchEngine = false;
$searchEngines = [
    'Baiduspider',
    'bingbot',
    '360Spider',
    'Sogou web spider',
    'YisouSpider',
];

foreach ($searchEngines as $bot) {
    if (stripos($userAgent, $bot) !== false) {
        $isSearchEngine = true;
        break;
    }
}

$pageTitle = $articlename . ' - ' . $chaptername;
if ($max_pid > 1) {
    $pageTitle .= '（' . $now_pid . '/' . $max_pid . '）';
}
$pageTitle .= ' - ' . SITE_NAME;

$pageDescription = '《' . $articlename . '》最新章节：' . $chaptername;
if ($max_pid > 1) {
    $pageDescription .= ' 第' . $now_pid . '页/共' . $max_pid . '页';
}
$pageDescription .= '，作者：' . $author . '。';
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title><?=$pageTitle?></title>
    <meta name="keywords" content="<?=$articlename?>,<?=$author?>,<?=$sortname?>,<?=$chaptername?>">
    <meta name="description" content="<?=$pageDescription?>">
    
    <meta http-equiv="Cache-Control" content="no-transform">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="mobile-agent" content="format=html5;url=<?=$uri?>">
    
    <meta property="og:type" content="novel">
    <meta property="og:title" content="<?=$pageTitle?>">
    <meta property="og:description" content="《<?=$articlename?>》<?=$chaptername?>：<?=$reader_des?>">
    <meta property="og:novel:category" content="<?=$sortname?>小说">
    <meta property="og:novel:author" content="<?=$author?>">
    <meta property="og:novel:book_name" content="<?=$articlename?>">
    <meta property="og:novel:index_url" content="<?=$info_url?>">
    <meta property="og:novel:info_url" content="<?=$info_url?>">
    <meta property="og:novel:status" content="<?=$isfull?>">
    <meta property="og:novel:chapter_name" content="<?=$chaptername?>">
    <meta property="og:novel:chapter_url" content="<?=$uri?>">

<?php require_once 'tpl_header.php'; ?>
<style>
.loading-text {
    text-align: center;
    padding: 40px 20px;
    color: #666;
    font-size: 16px;
}
.error-text {
    text-align: center;
    padding: 40px 20px;
    color: #f00;
    font-size: 16px;
}
.spider-pagination {
    position: absolute;
    left: -9999px;
    top: -9999px;
    height: 0;
    overflow: hidden;
}
.spider-pagination a {
    display: inline-block;
    margin: 0 5px;
    color: #333;
    text-decoration: none;
}
</style>
</head>
<body>
    <div class="read_bg"><main class="container">
    <section class="section_style">
        <div class="text">
            <div class="text_set">
                <i class="fr cog fa fa-cog fa-3x" onclick="javascript:cog();"></i>
                <div id="text_control">
                    <div class="fontsize">
                        <button onclick="javascript:changeSize('min');" title="缩小字号">A-</button> 
                        <button onclick="javascript:changeSize('normal');" title="标准字号"> A</button> 
                        <button onclick="javascript:changeSize('plus');" title="放大字号">A+</button>
                    </div>
                    <div>
                        <a href="javascript:alert('敬请期待')" title="加入书签"><i class="fa fa-bookmark"></i></a>
                        <a href="javascript:isnight();" title="白天夜间模式"><i class="fa fa-moon-o fa-flip-horizontal"></i></a>
                        <a href="javascript:;" title="极简模式"><i id="ismini" class="fa fa-minus-square" onclick="ismini();" ></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="text_title">
            <h1 class="style_h1">
                <?=$chaptername?>
                <?php if ($max_pid > 1): ?>
                <span style="font-size: 14px; color: #666; margin-left: 10px;">
                    （第<?=$now_pid?>页/共<?=$max_pid?>页）
                </span>
                <?php endif; ?>
            </h1>
            <div class="text_info">
                <span><a href="<?=$info_url?>"><i class="fa fa-book"> <?=$articlename?></i></a></span>
                <span><a href="<?=$author_url?>"><i class="fa fa-user-circle-o"> <?=$author?></i></a></span>
                <span><i class="fa fa-list-ol"> <?=$chapterwords?> 字</i></span>
                <span><i class="fa fa-clock-o"> <?=Text::ss_lastupdate($lastupdate)?></i></span>
                <span><i class="fa fa-file-text-o"> 页 <?=$now_pid?>/<?=$max_pid?></i></span>
            </div>
        </div>
        
        <div class="spider-pagination" aria-label="章节分页导航">
            <?php if ($max_pid > 1): ?>
                <?php if ($now_pid > 1): ?>
                    <a href="<?=$prevpage_url?>" rel="prev">上一页</a>
                <?php endif; ?>
                
                <span>第<?=$now_pid?>页/共<?=$max_pid?>页</span>
                
                <?php for ($i = 1; $i <= min($max_pid, 10); $i++): ?>
                    <?php if ($i == $now_pid): ?>
                        <strong><?=$i?></strong>
                    <?php else: ?>
                        <a href="/read/<?=$articleid?>/<?=$chapterid?>/<?=$i?>.html"><?=$i?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($now_pid < $max_pid): ?>
                    <a href="<?=$nextpage_url?>" rel="next">下一页</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        
        <article id="article" class="content">
            <?php if ($isSearchEngine || !Ss::use_js()): ?>
                <?php echo $rico_content; ?>
            <?php else: ?>
                <div class="loading-text">正在加载章节内容...</div>
            <?php endif; ?>
        </article>
        
        <div class="s_gray tc"><script>tips('<?=$articlename?>');</script></div>
    </section>
    <div class="read_nav">

        <?php if($prevpage_url != ''): ?>
            <a id="prev_url" href="<?=$prevpage_url?>"><i class="fa fa-backward"></i> 上一页</a>
        <?php else: ?>
            <?php if($pre_cid == 0): ?><a id="prev_url" href="<?=$info_url?>" class="w_gray"><i class="fa fa-stop"></i> 没有了</a><?php else: ?><a id="prev_url" href="<?=$pre_url?>"><i class="fa fa-backward"></i> 上一章</a><?php endif ?>
        <?php endif ?>

        <a id="info_url" href="<?=$info_url?>">书页/目录</a> 

        <?php if($nextpage_url != ''): ?>
            <a id="next_url" href="<?=$nextpage_url?>"><i class="fa fa-forward"></i> 下一页</a>
        <?php else: ?>
            <?php if($next_cid == 0): ?><a id="next_url" href="<?=$info_url?>" class="w_gray">没有了 <i class="fa fa-stop"></i></a><?php else: ?><a id="next_url" href="<?=$next_url ?>">下一章 <i class="fa fa-forward"></i></a><?php endif ?>
        <?php endif ?>

    </div>
</main></div>

<script>
   <?php if (Ss::use_js() && !$isSearchEngine) : ?>
      setTimeout(function() {
          $.ajax({
              type: "post",
              url: "/api/reader_js.php",
              data: {
                  articleid: '<?= $articleid ?>',
                  chapterid: '<?= $chapterid ?>',
                  pid: '<?= $now_pid ?>'
              },
              success: function(data) {
                  $('#article').html(data);
              },
              error: function() {
                  $('#article').html('<div class="error-text">加载失败，请刷新重试</div>');
              }
          });
      }, 200);
  <?php endif ?>

</script>
<?php require_once 'tpl_footer.php'; ?>
<script src="/static/<?=$theme_dir?>/style.js"></script>