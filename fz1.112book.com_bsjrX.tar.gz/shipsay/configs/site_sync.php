<?php
// 开关：1=启用
$site_sync_enable = 1;

// 分站同步密钥：必须与总控面板该站保存的 secret 完全一致
$site_sync_secret = 'b44fe3186dc85178ad7756d97dc8e058ebd02f569758a467385ed6c80c19fc06';

// 允许访问的总控服务器公网IP（强烈建议填写，安全）
// 先填你 zongkong 服务器的公网IP
$site_sync_allow_ips = [
  '216.250.254.115',
];

// 是否信任反代头（没走反代就 0；走了 Nginx/CF 反代再改 1）
$site_sync_trust_proxy_ip = 0;

// 时间窗口（秒）：总控和分站时间差超过这个就拒绝
$site_sync_ts_window = 300;

// nonce 过期（秒）：防重放
$site_sync_nonce_ttl = 600;

// 可选：分站侧日志
$site_sync_log = dirname(__DIR__, 2) . '/shipsay/configs/_bak/site_sync.log';

