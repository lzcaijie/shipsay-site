<?php if (!defined('__ROOT_DIR__')) exit;

header('Content-Type: application/json; charset=utf-8');

function ss_json_exit($arr, $code = 200){
  http_response_code($code);
  echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

$cfg = __ROOT_DIR__ . '/shipsay/configs/site_sync.php';
if (!is_file($cfg)) ss_json_exit(['ok'=>0,'error'=>'site_sync_not_configured'], 500);
require $cfg;

if (empty($site_sync_enable)) ss_json_exit(['ok'=>0,'error'=>'site_sync_disabled'], 403);

function ss_client_ip(){
  global $site_sync_trust_proxy_ip;
  $ip = $_SERVER['REMOTE_ADDR'] ?? '';
  if (!empty($site_sync_trust_proxy_ip)) {
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) $ip = trim($_SERVER['HTTP_X_REAL_IP']);
    else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      $tmp = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
      $ip = trim($tmp[0]);
    }
  }
  return $ip;
}

function ss_write_atomic($path, $content){
  $tmp = $path . '.tmp';
  if (@file_put_contents($tmp, $content, LOCK_EX) === false) return false;
  if (!@rename($tmp, $path)) return false;
  return true;
}

function ss_backup_file($path, $bak_dir, $prefix){
  if (!is_file($path)) return '';
  if (!is_dir($bak_dir)) @mkdir($bak_dir, 0755, true);
  $ts = date('Ymd_His');
  $bak = rtrim($bak_dir, '/').'/'.$prefix.'.bak_'.$ts;
  if (@copy($path, $bak)) return $bak;
  return '';
}

function ss_latest_backup($bak_dir, $prefix){
  $bak_dir = rtrim($bak_dir, '/');
  if (!is_dir($bak_dir)) return '';
  $files = glob($bak_dir.'/'.$prefix.'.bak_*');
  if (empty($files)) return '';
  rsort($files);
  return $files[0];
}

function ss_clean_backups($bak_dir, $prefix, $keep = 30){
  $bak_dir = rtrim($bak_dir, '/');
  if (!is_dir($bak_dir)) return;
  $files = glob($bak_dir.'/'.$prefix.'.bak_*');
  if (empty($files)) return;
  rsort($files);
  if (count($files) <= $keep) return;
  $del = array_slice($files, $keep);
  foreach ($del as $f) @unlink($f);
}

$ip = ss_client_ip();
if (!empty($site_sync_allow_ips) && is_array($site_sync_allow_ips) && !in_array($ip, $site_sync_allow_ips, true)) {
  ss_json_exit(['ok'=>0,'error'=>'ip_denied','ip'=>$ip], 403);
}

$ts    = $_SERVER['HTTP_X_SS_TS'] ?? '';
$nonce = $_SERVER['HTTP_X_SS_NONCE'] ?? '';
$sign  = $_SERVER['HTTP_X_SS_SIGN'] ?? '';

if ($ts==='' || $nonce==='' || $sign==='') ss_json_exit(['ok'=>0,'error'=>'missing_headers'], 401);
if (!ctype_digit($ts)) ss_json_exit(['ok'=>0,'error'=>'bad_ts'], 401);

$ts_i = intval($ts);
if (abs(time() - $ts_i) > intval($site_sync_ts_window)) {
  ss_json_exit(['ok'=>0,'error'=>'ts_expired'], 401);
}
if (!preg_match('/^[a-zA-Z0-9\-_]{8,64}$/', $nonce)) {
  ss_json_exit(['ok'=>0,'error'=>'bad_nonce'], 401);
}

$raw = file_get_contents('php://input');
if ($raw === false) $raw = '';
$body_hash = hash('sha256', $raw);

$base = "POST\n/api/site_sync.php\n{$ts}\n{$nonce}\n{$body_hash}";
$calc = hash_hmac('sha256', $base, $site_sync_secret);
if (!hash_equals($calc, $sign)) {
  ss_json_exit(['ok'=>0,'error'=>'bad_sign'], 401);
}

$nonce_ok = true;
$nonce_key = 'ss_site_sync_nonce_' . $nonce;

global $use_redis, $redis;
if (!empty($use_redis) && isset($redis) && $redis instanceof Redis) {
  $exists = $redis->get($nonce_key);
  if ($exists) $nonce_ok = false;
  else $redis->setex($nonce_key, intval($site_sync_nonce_ttl), '1');
} else {
  $dir = __ROOT_DIR__ . '/shipsay/cache/nonces';
  if (!is_dir($dir)) @mkdir($dir, 0755, true);
  $f = $dir . '/' . $nonce;
  if (is_file($f)) $nonce_ok = false;
  else @file_put_contents($f, (string)time(), LOCK_EX);
}

if (!$nonce_ok) ss_json_exit(['ok'=>0,'error'=>'replay_detected'], 401);

$data = json_decode($raw, true);
if (empty($data) || !is_array($data)) ss_json_exit(['ok'=>0,'error'=>'bad_json'], 400);

$check_only = !empty($data['check_only']);
$do_rollback = !empty($data['rollback']);

$override = __ROOT_DIR__ . '/shipsay/configs/override_pre.php';
$bak_dir = __ROOT_DIR__ . '/shipsay/configs/_bak';
$bak_prefix = 'override_pre.php';

if ($do_rollback) {
  $latest = ss_latest_backup($bak_dir, $bak_prefix);
  if ($latest !== '' && is_file($latest)) {
    $content = @file_get_contents($latest);
    if ($content === false) ss_json_exit(['ok'=>0,'error'=>'rollback_read_failed'], 500);
    if (!ss_write_atomic($override, $content)) ss_json_exit(['ok'=>0,'error'=>'rollback_write_failed'], 500);
    ss_json_exit(['ok'=>1,'rollback'=>1,'used'=>$latest]);
  }
  if (is_file($override)) {
    @unlink($override);
    ss_json_exit(['ok'=>1,'rollback'=>1,'used'=>'delete_override']);
  }
  ss_json_exit(['ok'=>1,'rollback'=>1,'used'=>'no_backup_no_override']);
}

$fields = [
  'site_name'       => ['type'=>'string','max'=>60],
  'theme_dir'       => ['type'=>'slug','max'=>40],
  'kw_pack_id'      => ['type'=>'int','min'=>1,'max'=>99],
  'enable_protect'  => ['type'=>'bool'],

  'fake_info_url'    => ['type'=>'string','max'=>200],
  'fake_chapter_url' => ['type'=>'string','max'=>200],
  'fake_sort_url'    => ['type'=>'string','max'=>200],
  'fake_top'         => ['type'=>'string','max'=>200],
  'fake_recentread'  => ['type'=>'string','max'=>200],
  'fake_indexlist'   => ['type'=>'string','max'=>200],
];

$apply = [];
foreach ($fields as $k => $rule) {
  if (!array_key_exists($k, $data)) continue;
  $v = $data[$k];

  if ($rule['type'] === 'string') {
    $v = is_null($v) ? '' : (string)$v;
    $v = str_replace(["\0"], [''], $v);
    if (strlen($v) > $rule['max']) $v = substr($v, 0, $rule['max']);
    $apply[$k] = $v;
  } elseif ($rule['type'] === 'slug') {
    $v = is_null($v) ? '' : (string)$v;
    if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $v)) ss_json_exit(['ok'=>0,'error'=>'bad_theme_dir'], 400);
    if (strlen($v) > $rule['max']) $v = substr($v, 0, $rule['max']);
    $apply[$k] = $v;
  } elseif ($rule['type'] === 'int') {
    if (!is_numeric($v)) ss_json_exit(['ok'=>0,'error'=>'bad_int_'.$k], 400);
    $iv = intval($v);
    if (isset($rule['min']) && $iv < $rule['min']) $iv = $rule['min'];
    if (isset($rule['max']) && $iv > $rule['max']) $iv = $rule['max'];
    $apply[$k] = $iv;
  } elseif ($rule['type'] === 'bool') {
    $apply[$k] = (!empty($v) && (string)$v !== '0') ? 1 : 0;
  }
}

if (empty($apply)) {
  if ($check_only) ss_json_exit(['ok'=>1,'check_only'=>1,'would_apply'=>new stdClass()]);
  ss_json_exit(['ok'=>0,'error'=>'nothing_to_apply'], 400);
}

if ($check_only) ss_json_exit(['ok'=>1,'check_only'=>1,'would_apply'=>$apply]);

$bak = ss_backup_file($override, $bak_dir, $bak_prefix);
ss_clean_backups($bak_dir, $bak_prefix, 30);

$lines = [];
$lines[] = "<?php";
$lines[] = "";
if (isset($apply['site_name'])) {
  $lines[] = '$site_name = ' . var_export($apply['site_name'], true) . ';';
}
if (isset($apply['theme_dir'])) {
  $lines[] = '$theme_dir = ' . var_export($apply['theme_dir'], true) . ';';
}
if (isset($apply['kw_pack_id'])) {
  $lines[] = '$kw_pack_id = ' . intval($apply['kw_pack_id']) . ';';
}
if (isset($apply['enable_protect'])) {
  $lines[] = '$enable_protect = ' . intval($apply['enable_protect']) . ';';
}
foreach (['fake_info_url','fake_chapter_url','fake_sort_url','fake_top','fake_recentread','fake_indexlist'] as $fk) {
  if (isset($apply[$fk])) $lines[] = '$' . $fk . ' = ' . var_export($apply[$fk], true) . ';';
}
$php = implode("\n", $lines) . "\n";

if (!ss_write_atomic($override, $php)) ss_json_exit(['ok'=>0,'error'=>'write_failed'], 500);

if (!empty($site_sync_log)) {
  $log_dir = dirname($site_sync_log);
  if (!is_dir($log_dir)) @mkdir($log_dir, 0755, true);
  @file_put_contents($site_sync_log, date('Y-m-d H:i:s')." ip={$ip} apply=".json_encode($apply,JSON_UNESCAPED_UNICODE)."\n", FILE_APPEND);
}

ss_json_exit(['ok'=>1,'applied'=>$apply,'backup'=>$bak ? $bak : '']);
